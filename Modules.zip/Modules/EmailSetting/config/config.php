<?php

return [
    'name' => 'EmailSetting',
];
