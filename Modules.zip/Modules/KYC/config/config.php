<?php

return [
    'name' => 'KYC',
];
