<?php

return [
    'name' => 'Currency',
];
