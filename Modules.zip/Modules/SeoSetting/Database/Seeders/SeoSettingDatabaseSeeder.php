<?php

namespace Modules\SeoSetting\Database\Seeders;

use Illuminate\Database\Seeder;

class SeoSettingDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
