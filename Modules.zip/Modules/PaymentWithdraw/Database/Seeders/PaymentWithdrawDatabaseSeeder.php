<?php

namespace Modules\PaymentWithdraw\Database\Seeders;

use Illuminate\Database\Seeder;

class PaymentWithdrawDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
