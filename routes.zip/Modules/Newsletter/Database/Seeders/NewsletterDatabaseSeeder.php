<?php

namespace Modules\Newsletter\Database\Seeders;

use Illuminate\Database\Seeder;

class NewsletterDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
