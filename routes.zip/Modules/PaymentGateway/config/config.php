<?php

return [
    'name' => 'PaymentGateway',
];
