 <!-- section start -->
 <section class="">
        <div class="ourteam-banner d-flex justify-content-center align-items-center">
            <div class="container">
                <div class="row text-center ">
                    <h1 class="team1 text-white">Our Blogs</h1>
                    <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nulla dolore
                        fuga,
                        exercitationem non laudantium, optio commodi esse, officiis aliquam repellat obcaecati mollitia
                        incidunt quasi rerum est quibusdam cumque voluptate? Lorem ipsum dolor sit amet consectetur
                        adipisicing elit. Sapiente nulla dolore fuga,
                        exercitationem non laudantium, optio commodi esse, officiis aliquam repellat obcaecati mollitia
                        incidunt quasi rerum est quibusdam cumque voluptate?</p>
                </div>
            </div>
        </div>


        <div class="container">
            <div class="row my-5">
                <div class="col-md-6">
                    <h2 class="fw-bold">Meet The Professionals Team </h2>
                </div>

                <div class="col-md-6">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                        of type and scrambled it to make a type specimen book.</p>
                </div>
            </div>

            <div class="row my-5">

                  <div class="col-md-4 mb-4">
                    <a href="blog-details.html" class="text-decoration-none">
                        <div class="card p-3 blog-card">
                            <img src="img/image-25.png" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">What is Lorem Ipsum?</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="#" class="text-decoration-none card-a"> <span><img src="img/Man.png" alt=""></span> &nbsp; Jonathan Wills</a>
                            </div>
                        </div>
                    </a>
                 </div>
            

                <div class="col-md-4 mb-4">
                    <a href="blog-details.html" class="text-decoration-none">
                        <div class="card p-3 blog-card">
                            <img src="img/image-25.png" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">What is Lorem Ipsum?</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="#" class="text-decoration-none card-a"> <span><img src="img/Man.png" alt=""></span> &nbsp; Jonathan Wills</a>
                            </div>
                        </div>
                    </a>
                </div>


                <div class="col-md-4 mb-4">
                    <a href="blog-details.html" class="text-decoration-none">
                        <div class="card p-3 blog-card">
                            <img src="img/image-25.png" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">What is Lorem Ipsum?</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="#" class="text-decoration-none card-a"> <span><img src="img/Man.png" alt=""></span> &nbsp; Jonathan Wills</a>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 mb-4">
                    <a href="blog-details.html" class="text-decoration-none">
                        <div class="card p-3 blog-card">
                            <img src="img/image-25.png" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">What is Lorem Ipsum?</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="#" class="text-decoration-none card-a"> <span><img src="img/Man.png" alt=""></span> &nbsp; Jonathan Wills</a>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 mb-4">
                    <a href="blog-details.html" class="text-decoration-none">
                        <div class="card p-3 blog-card">
                            <img src="img/image-25.png" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">What is Lorem Ipsum?</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="#" class="text-decoration-none card-a"> <span><img src="img/Man.png" alt=""></span> &nbsp; Jonathan Wills</a>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 mb-4">
                    <a href="blog-details.html" class="text-decoration-none">
                        <div class="card p-3 blog-card">
                            <img src="img/image-25.png" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">What is Lorem Ipsum?</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="#" class="text-decoration-none card-a"> <span><img src="img/Man.png" alt=""></span> &nbsp; Jonathan Wills</a>
                            </div>
                        </div>
                    </a>
                </div>

               <div class="text-center">
                <button class="btn btn-red">View more</button>
               </div>
                
               
            </div>
        </div>
    </section>

    <!-- section end -->