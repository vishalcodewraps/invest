<?php

return [
    'name' => 'City'
];
