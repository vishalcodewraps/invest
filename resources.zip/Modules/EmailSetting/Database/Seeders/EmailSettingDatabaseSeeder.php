<?php

namespace Modules\EmailSetting\Database\Seeders;

use Illuminate\Database\Seeder;

class EmailSettingDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
