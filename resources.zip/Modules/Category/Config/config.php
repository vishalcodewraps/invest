<?php

return [
    'name' => 'Category'
];
