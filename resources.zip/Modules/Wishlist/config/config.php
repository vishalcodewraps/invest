<?php

return [
    'name' => 'Wishlist',
];
