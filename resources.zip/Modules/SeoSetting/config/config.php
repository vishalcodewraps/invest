<?php

return [
    'name' => 'SeoSetting',
];
